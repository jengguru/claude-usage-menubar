# Copyright (c) 2025, NVIDIA
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.  THIS SOFTWARE IS
# PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
# NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import argparse
import importlib.metadata
import platform
import sys
from typing import Optional

from pyeclib import ec_iface

version_description = "print pyeclib and liberasurecode versions"


def version_command(args: Optional[argparse.Namespace] = None) -> None:
    print(f"pyeclib {ec_iface.__version__}")
    bundled = ""
    try:
        files = importlib.metadata.files("pyeclib") or []
        if any(f.name.startswith("liberasurecode-pyeclib.so") for f in files):
            bundled = " (bundled)"
    except importlib.metadata.PackageNotFoundError:
        pass
    print(f"liberasurecode {ec_iface.LIBERASURECODE_VERSION}{bundled}")
    version_str = sys.version.split(" (", 1)[0]
    print(f"{platform.python_implementation()} {version_str}")


if __name__ == "__main__":
    version_command()
